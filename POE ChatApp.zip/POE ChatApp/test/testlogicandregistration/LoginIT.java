/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package testlogicandregistration;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_lab
 */
public class LoginIT {
    Login instance;
    
    public LoginIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        // Example of a valid user
        instance = new Login("Mak_1", "StrongPass1@", "+27831234567");
    }

    @After
    public void tearDown() {
        instance = null;
    }

    @Test
    public void testCheckUserName() {
        System.out.println("checkUserName");
        assertTrue(instance.checkUserName()); 
    }

    @Test
    public void testCheckPasswordComplexity() {
        System.out.println("checkPasswordComplexity");
        assertTrue(instance.checkPasswordComplexity()); 
    }

    @Test
    public void testCheckCellPhoneNumber() {
        System.out.println("checkCellPhoneNumber");
        assertTrue(instance.checkCellPhoneNumber()); 
    }

    @Test
    public void testRegisterUser() {
        System.out.println("registerUser");
        String result = instance.registerUser();
        assertTrue(result.contains("successfully")); 
    }

    @Test
    public void testLoginUser() {
        System.out.println("loginUser");
        boolean loginResult = instance.loginUser("Mak_1", "StrongPass1@");
        assertTrue(loginResult);
    }

    @Test
    public void testGetUsername() {
        System.out.println("getUsername");
        assertEquals("Mak_1", instance.getUsername());
    }
}