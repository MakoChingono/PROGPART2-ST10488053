/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package messageapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author RC_Student_Lab
 */
public class MessagesIT {
    
    public MessagesIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of checkMessageID method, of class Messages.
     */
    @Test
    public void testCheckMessageID() {
        System.out.println("checkMessageID");
        Messages instance = new Messages("+27834557896", "Hello");
        boolean result = instance.checkMessageID();
        assertTrue(result);
        
    }

    /**
     * Test of checkRecipientCell method, of class Messages.
     */
    @Test
    public void testCheckRecipientCell() {
        System.out.println("checkRecipientCell");
        Messages instance = new Messages("+2783455789", "Hello");
        boolean result = instance.checkRecipientCell();
        assertTrue(result);
            }

    /**
     * Test of SentMessages method, of class Messages.
     */
    @Test
    public void testSentMessages() {
        System.out.println("SentMessages");
        String option = "";
        Messages instance = new Messages("+2791356543", "Hi");
        String expResult ="Invalid option. Type 'send', 'store', or 'disregard'.";
        String result = instance.SentMessages(option);
        assertEquals("Invalid option. Type 'send', 'store', or 'disregard'.", result);
        
    }

   /**
     * Test of storeMessage method, of class Messages.
     */
    @Test
    public void testStoreMessage() {
        System.out.println("storeMessage");
        Messages instance = new Messages("+2791356432", "store");
        instance.storeMessage();
        
    }

    /**
     * Test of readStoredMessagesFromJSON method, of class Messages.
     */
    @Test
    public void testReadStoredMessagesFromJSON() {
        System.out.println("readStoredMessagesFromJSON");
        Messages.readStoredMessagesFromJSON();
            }

    /**
     * Test of displaySentMessages method, of class Messages.
     */
    @Test
    public void testDisplaySentMessages() {
        System.out.println("displaySentMessages");
        String expResult = "No sent messages found.";
        String result = Messages.displaySentMessages();
        assertEquals("No sent messages found.", result);
            }

    /**
     * Test of displayLongestMessage method, of class Messages.
     */
    @Test
    public void testDisplayLongestMessage() {
        System.out.println("displayLongestMessage");
        String expResult = "No messages found.";
        String result = Messages.displayLongestMessage();
        assertEquals("No messages found.", result);
            }

    /**
     * Test of searchMessagesByRecipient method, of class Messages.
     */
    @Test
    public void testSearchMessagesByRecipient() {
        System.out.println("searchMessagesByRecipient");
        String recipientNumber = "+2791364354";
        String expResult = "No messages found for this recipient.";
        String result = Messages.searchMessagesByRecipient(recipientNumber);
        assertEquals("No messages found for this recipient.", result);
        
    }

    /**
     * Test of searchMessageByID method, of class Messages.
     */
    @Test
    public void testSearchMessageByID() {
        System.out.println("searchMessageByID");
        String id = "";
        String expResult = "Message ID not found.";
        String result = Messages.searchMessageByID(id);
        assertEquals("Message ID not found.", result);
            }

    /**
     * Test of deleteMessageByHash method, of class Messages.
     */
    @Test
    public void testDeleteMessageByHash() {
        System.out.println("deleteMessageByHash");
        String hash = "";
        String expResult = "Message hash not found.";
        String result = Messages.deleteMessageByHash(hash);
        assertEquals("Message hash not found.", result);
        
    }

    /**
     * Test of displayMessageReport method, of class Messages.
     */
    @Test
    public void testDisplayMessageReport() {
        System.out.println("displayMessageReport");
        String expResult = "No sent messages to report.";
        String result = Messages.displayMessageReport();
        assertEquals("No sent messages to report.", result);
        
    }

    /**
     * Test of getMessageID method, of class Messages.
     */
    @Test
    public void testGetMessageID() {
        System.out.println("getMessageID");
        Messages instance = new Messages("1415800678", "Hi");
        String expResult = "";
        String result = instance.getMessageID();
        assertNotNull("", result);
            }

    /**
     * Test of getMessageHash method, of class Messages.
     */
    @Test
    public void testGetMessageHash() {
        System.out.println("getMessageHash");
        Messages instance = new Messages("+270792345678", "Hi");
        String expResult = "";
        String result = instance.getMessageHash();
        assertNotNull("", result);
            }

    /**
     * Test of getRecipient method, of class Messages.
     */
    @Test
    public void testGetRecipient() {
        System.out.println("getRecipient");
        Messages instance = new Messages("+270987654321", "Hi");
        String expResult = "+270987654321";
        String result = instance.getRecipient();
        assertEquals("+270987654321", result);
        
    }

    /**
     * Test of getMessage method, of class Messages.
     */
    @Test
    public void testGetMessage() {
        System.out.println("getMessage");
        Messages instance = new Messages("+275432467890", "Hi");
        String expResult = "Hi";
        String result = instance.getMessage();
        assertEquals("Hi", result);
            }

    /**
     * Test of printMessages method, of class Messages.
     */
    @Test
    public void testPrintMessages() {
        System.out.println("printMessages");
        String expResult = "No sent messages found.";
        String result = Messages.printMessages();
        assertEquals("No sent messages found.", result);
        
    }

    /**
     * Test of getMessageCount method, of class Messages.
     */
    @Test
    public void testGetMessageCount() {
        System.out.println("getMessageCount");
        int expResult = 0;
        int result = Messages.getMessageCount();
        assertEquals(expResult, result);
        
    }

    /**
     * Test of getAllMessagesAsString method, of class Messages.
     */
    @Test
    public void testGetAllMessagesAsString() {
        System.out.println("getAllMessagesAsString");
        String expResult = "No sent messages found.";
        String result = Messages.getAllMessagesAsString();
        assertEquals("No sent messages found.", result);
            }

    /**
     * Test of quickChatMenu method, of class Messages.
     */
    @Test
    public void testQuickChatMenu() {
        System.out.println("quickChatMenu");
        String username = "";
        Messages.quickChatMenu(username);
            }
    
}
