//OpenAI. ChatGPT (GPT-5-mini). OpenAI, 19 Novemvber. 2025, https://chat.openai.com.

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messageapp;

/**
 *
 * @author RC_Student_Lab
 */

import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import messageapp.Messages;


public class Messages {


private static int totalMessages = 0;
private static int numSent = 0;


private static ArrayList<Messages> sentMessagesArr = new ArrayList<>();
private static ArrayList<Messages> storedMessagesArr = new ArrayList<>();
private static ArrayList<Messages> disregardedMessagesArr = new ArrayList<>();
private static ArrayList<String> messageHashes = new ArrayList<>();
private static ArrayList<String> messageIDs = new ArrayList<>();

private static JSONArray storedMessagesJSON = new JSONArray();

// Instance Variables
private final String messageID;
private final String recipient;
private final String message;
private final String messageHash;

//Constructor
public Messages(String recipient, String message) {
    this.messageID = generateMessageID();
    this.recipient = recipient;
    this.message = message;
    this.messageHash = createMessageHash();
}

//Helper Methods
private String generateMessageID() {
    Random rand = new Random();
    StringBuilder id = new StringBuilder();
    for (int i = 0; i < 10; i++) id.append(rand.nextInt(10));
    return id.toString();
}

private String createMessageHash() {
    String[] words = message.split(" ");
    String firstWord = words.length > 0 ? words[0] : "";
    String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
    return messageID.substring(0, 2) + ":" + numSent + ":" + (firstWord + lastWord).toUpperCase();
}

// Validation Methods
public boolean checkMessageID() { return messageID.length() <= 10; }
public boolean checkRecipientCell() { return recipient.startsWith("+") && recipient.length() <= 12; }

// Core Functional Methods
public String SentMessages(String option) {
    switch(option.toLowerCase()) {
        case "send":
            if(message.length() > 250) return "Please enter a message of less than 250 characters.";
            numSent++;
            totalMessages++;
            sentMessagesArr.add(this);
            messageIDs.add(messageID);
            messageHashes.add(messageHash);
            JOptionPane.showMessageDialog(null,
                    "Message sent successfully!\nMessageID: " + messageID +
                    "\nMessageHash: " + messageHash +
                    "\nRecipient: " + recipient +
                    "\nMessage: " + message +
                    "\nTotal messages sent: " + totalMessages);
            return "Message successfully sent.";

        case "store":
            storeMessage();
            storedMessagesArr.add(this);
            messageIDs.add(messageID);
            messageHashes.add(messageHash);
            return "Message successfully stored.";

        case "disregard":
            disregardedMessagesArr.add(this);
            return "Message discarded.";

        default:
            return "Invalid option. Type 'send', 'store', or 'disregard'.";
    }
}


public void storeMessage() {
    JSONObject msgObj = new JSONObject();
    msgObj.put("MessageID", messageID);
    msgObj.put("Recipient", recipient);
    msgObj.put("Message", message);
    msgObj.put("MessageHash", messageHash);
    storedMessagesJSON.add(msgObj);
    try(FileWriter file = new FileWriter("messages.json")) {
        file.write(storedMessagesJSON.toJSONString());
        file.flush();
    } catch(IOException e) { e.printStackTrace(); }
}


public static void readStoredMessagesFromJSON() {
    JSONParser parser = new JSONParser();
    try(FileReader reader = new FileReader("messages.json")) {
        JSONArray arr = (JSONArray) parser.parse(reader);
        storedMessagesArr.clear();
        for(Object obj : arr) {
            JSONObject jsonMsg = (JSONObject) obj;
            String rec = (String) jsonMsg.get("Recipient");
            String msg = (String) jsonMsg.get("Message");
            Messages messageObj = new Messages(rec, msg);
            storedMessagesArr.add(messageObj);
        }
    } catch(IOException | ParseException e) { e.printStackTrace(); }
}

//  Display all sent messages
public static String displaySentMessages() {
    if(sentMessagesArr.isEmpty()) return "No sent messages found.";
    StringBuilder sb = new StringBuilder("=== Sent Messages ===\n");
    for(Messages msg : sentMessagesArr)
        sb.append("Recipient: ").append(msg.recipient)
          .append("\nMessage: ").append(msg.message)
          .append("\nMessageID: ").append(msg.messageID)
          .append("\nMessageHash: ").append(msg.messageHash)
          .append("\n\n");
    return sb.toString();
}

//Longest message
public static String displayLongestMessage() {
    ArrayList<Messages> all = new ArrayList<>();
    all.addAll(sentMessagesArr);
    all.addAll(storedMessagesArr);
    all.addAll(disregardedMessagesArr);
    if(all.isEmpty()) return "No messages found.";
    Messages longest = all.get(0);
    for(Messages msg : all) if(msg.message.length() > longest.message.length()) longest = msg;
    return longest.message;
}

//Search by recipient
public static String searchMessagesByRecipient(String recipientNumber) {
    StringBuilder sb = new StringBuilder();
    for(Messages msg : sentMessagesArr) if(msg.recipient.equals(recipientNumber)) sb.append(msg.message).append("\n");
    for(Messages msg : storedMessagesArr) if(msg.recipient.equals(recipientNumber)) sb.append(msg.message).append("\n");
    return sb.length() == 0 ? "No messages found for this recipient." : sb.toString();
}

//Search by ID
public static String searchMessageByID(String id) {
    for(Messages msg : sentMessagesArr) if(msg.messageID.equals(id)) return "Recipient: " + msg.recipient + "\nMessage: " + msg.message;
    return "Message ID not found.";
}

//Delete by hash
public static String deleteMessageByHash(String hash) {
    for(Messages msg : sentMessagesArr) {
        if(msg.messageHash.equals(hash)) {
            sentMessagesArr.remove(msg);
            messageHashes.remove(hash);
            return "Message \"" + msg.message + "\" successfully deleted.";
        }
    }
    return "Message hash not found.";
}

//Display report
public static String displayMessageReport() {
    if(sentMessagesArr.isEmpty()) return "No sent messages to report.";
    StringBuilder sb = new StringBuilder("=== Message Report ===\n");
    for(Messages msg : sentMessagesArr) {
        sb.append("Message Hash: ").append(msg.messageHash)
          .append("\nRecipient: ").append(msg.recipient)
          .append("\nMessage: ").append(msg.message)
          .append("\n---------------------------\n");
    }
    return sb.toString();
}

// Getters
public String getMessageID() { return messageID; }
public String getMessageHash() { return messageHash; }
public String getRecipient() { return recipient; }
public String getMessage() { return message; }

public static String printMessages() {
    return displaySentMessages();
}


public static int getMessageCount() {
    return sentMessagesArr.size();
}


public static String getAllMessagesAsString() {
    return displaySentMessages();
}



public static void quickChatMenu(String username) {
    readStoredMessagesFromJSON();
    JOptionPane.showMessageDialog(null, "Welcome to QuickChat, " + username + "!");

    boolean running = true;
    while(running) {
        String choice = JOptionPane.showInputDialog(
            "Choose an option:\n" +
            "1) Send Message\n" +
            "2) Show Sent Messages\n" +
            "3) Search by Recipient\n" +
            "4) Search by Message ID\n" +
            "5) Delete Message by Hash\n" +
            "6) Show Longest Message\n" +
            "7) Show Message Report\n" +
            "8) Quit"
        );

        if(choice == null) return;

        switch(choice) {
            case "1":
                String rec = JOptionPane.showInputDialog("Enter recipient (+27...):");
                String msgText = JOptionPane.showInputDialog("Enter message:");
                if(rec != null && msgText != null) {
                    Messages newMsg = new Messages(rec, msgText);
                    if(newMsg.checkRecipientCell() && newMsg.checkMessageID()) {
                        newMsg.SentMessages("send");
                    } else JOptionPane.showMessageDialog(null,"Invalid recipient or message ID.");
                }
                break;

            case "2":
                JOptionPane.showMessageDialog(null, displaySentMessages());
                break;

            case "3":
                String searchRec = JOptionPane.showInputDialog("Enter recipient number (+27...) to search:");
                if(searchRec != null) JOptionPane.showMessageDialog(null, searchMessagesByRecipient(searchRec));
                break;

            case "4":
                String searchID = JOptionPane.showInputDialog("Enter Message ID to search:");
                if(searchID != null) JOptionPane.showMessageDialog(null, searchMessageByID(searchID));
                break;

            case "5":
                String delHash = JOptionPane.showInputDialog("Enter Message Hash to delete:");
                if(delHash != null) JOptionPane.showMessageDialog(null, deleteMessageByHash(delHash));
                break;

            case "6":
                JOptionPane.showMessageDialog(null, "Longest Message: \n" + displayLongestMessage());
                break;

            case "7":
                JOptionPane.showMessageDialog(null, displayMessageReport());
                break;

            case "8":
                running = false;
                JOptionPane.showMessageDialog(null,"Goodbye!");
                break;

            default:
                JOptionPane.showMessageDialog(null,"Invalid choice.");
                break;
        }
    }
}}