/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testlogicandregistration;

/**
 *
 * @author RC_Student_lab
 */

import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import messageapp.Messages;


public class TestLogicAndRegistration{
    
    private JFrame frame;
    private JTextField userField, cellField, messageField;
    private JPasswordField passField;
    private JButton registerBtn, sendMessageBtn;
    private JButton loginBtn;
    private Messages newMessage;
    private JTextArea resultArea;
    private Login registeredUser; // Logic class
    private Messages msg;
  
    
    

    public TestLogicAndRegistration() {
        frame = new JFrame("Registration Form");
        frame.setSize(500, 450);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(new Color(0, 102, 204));
        frame.setLayout(new GridLayout(7, 2, 10, 10));
        
        

        //Registration components
        userField = new JTextField();
        passField = new JPasswordField();
        cellField = new JTextField();
        registerBtn = new JButton("Register");
        loginBtn = new JButton("Login");
        
        //Message Components
        messageField = new JTextField();
        sendMessageBtn = new JButton("Send Message");
        
        //Result area
        resultArea = new JTextArea();
        resultArea.setEditable(false);

        // Add components
        frame.add(new JLabel("Username:")); frame.add(userField);
        frame.add(new JLabel("Password:")); frame.add(passField);
        frame.add(new JLabel("Cell Number (+27...):")); frame.add(cellField);
        frame.add(new JLabel()); frame.add(registerBtn);
        frame.add(loginBtn);
        frame.add(new JLabel("Result:")); frame.add(resultArea);

        // Register Button
        registerBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passField.getPassword());
                String cellNumber = cellField.getText();

                registeredUser = new Login(username, password, cellNumber);
                String result = registeredUser.registerUser();
                resultArea.setText(result);
            }
        });
        
        
        //Login Button Action
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (registeredUser == null) {
                    JOptionPane.showMessageDialog(frame, "Please register first!");
                    return;
                }

                String enteredUsername = userField.getText();
                String enteredPassword = new String(passField.getPassword());

                boolean loginSuccess = registeredUser.loginUser(enteredUsername, enteredPassword);

                if (loginSuccess) {
                    JOptionPane.showMessageDialog(frame, "Welcome to QuickChat."); // Requirement #2
                    frame.dispose();
                    showMenu(registeredUser); // Opens numeric menu
                } else {
                    JOptionPane.showMessageDialog(frame, "Login failed. Try again.");
                }
            }
        });

        frame.setVisible(true);
    }

    // New method: Menu after login
    private void showMenu(Login user) {
        boolean running = true;
        while (running) {
            String choice = JOptionPane.showInputDialog(null,
                    "Welcome to QuickChat.\n\nPlease choose an option:\n"
                    + "1) Send Messages\n"
                    + "2) Show recently sent messages\n"
                    + "3) Quit",
                    "QuickChat Menu", JOptionPane.QUESTION_MESSAGE);

            if (choice == null) break; // user pressed cancel

            switch (choice.trim()) {
                case "1":
                    SwingUtilities.invokeLater(() -> new MessagingScreen(user)); // opens message screen
                    running = false;
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon."); // Requirement #1b
                    break;
                case "3":
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    running = false;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Please enter 1, 2, or 3.");
            }
        }
    }

    public static void main(String[] args) {
        new TestLogicAndRegistration();
    }
}

// Messaging Screen remains mostly the same
class MessagingScreen extends JFrame {

    private JTextField msgField, recipientField;
    private JButton sendBtn, backBtn; //Added back button
    private JTextArea resultArea;
    private Messages newMessage;
    private Login user;

    public MessagingScreen(Login user) { 
        this.user = user;
        setTitle("Messaging App - " + user.getUsername());
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(230, 240, 255));
        setLayout(new GridLayout(6, 2, 10, 10));

        recipientField = new JTextField();
        msgField = new JTextField();
        sendBtn = new JButton("Send Message");
        backBtn = new JButton("Back to Menu"); //New button
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        add(new JLabel("Recipient Cell (+27...):")); add(recipientField);
        add(new JLabel("Enter Message:")); add(msgField);
        add(sendBtn); add(backBtn); // Add new back button
        add(new JLabel("Result:")); add(resultArea);

        // Send message action
        sendBtn.addActionListener(e -> {
            String recipient = recipientField.getText();
            String messageText = msgField.getText();
            //Character length
            if (messageText.length() >250){
                JOptionPane.showMessageDialog(this, "Please enter a message of less than 50 characters");
                return;
            }

             newMessage = new Messages(recipient, messageText);

            boolean validMessageID = newMessage.checkMessageID();
            boolean validRecipient = newMessage.checkRecipientCell(); 

if (validMessageID && validRecipient) {
    String result = newMessage.SentMessages("send"); 
    
  

    
    JOptionPane.showMessageDialog(this, "Message was sent succesfully!\n\n" + "Message ID:" + newMessage.getMessageID() + "\n" +
       "Recipient:" + recipient + "\n" +"Messages Sent:" +
            Messages.getMessageCount());
    
    resultArea.setText(result + "\n\n" + Messages.getAllMessagesAsString());
} else {
    JOptionPane.showMessageDialog(this, "Invalid message ID or cell number.");
}


       
        });

        // Back to menu
        backBtn.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> {
                new TestLogicAndRegistration(); // reopen main menu
            });
        });

        setVisible(true);
    }
}

        

