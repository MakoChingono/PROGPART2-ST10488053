/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package testlogicandregistration;

/**
 *
 * @author RC_Student_Lab
 */

import java.util.ArrayList;
public class Messages {


    private String recipient;
    private String text;

    // Static list to store all sent messages
    private static ArrayList<String> sentMessages = new ArrayList<>();

    // Constructor
    public Messages(String recipient, String text) {
        this.recipient = recipient;
        this.text = text;
    }

    // Send message method
    public String sendMessage(String command) {
        if(text == null || text.trim().isEmpty()) {
            return "Cannot send empty message.";
        }

        // Add message to the sentMessages list
        sentMessages.add("To: " + recipient + " | Message: " + text);
        return "Message sent to " + recipient;
    }

    // Print all sent messages
    public static String printMessages() {
        if(sentMessages.isEmpty()) return "No messages sent yet.";

        StringBuilder sb = new StringBuilder();
        for(String m : sentMessages) {
            sb.append(m).append("\n");
        }
        return sb.toString();
    }

    // Optional: getters
    public String getRecipient() { return recipient; }
    public String getText() { return text; 
    }

























}
    